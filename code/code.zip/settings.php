<?php
// THIS IS THE CLOUDINARY CONFIG FOR MY ACCOUNT
// This file is modified version from this project https://github.com/cloudinary/cloudinary_php/tree/master/samples/PhotoAlbum
Cloudinary::config(array(
    "cloud_name" => "mountaincoding",
    "api_key" => "338847965487949",
    "api_secret" => "kkvWSeHy51X2wdldwbW9jCNwifw"
));
?>
